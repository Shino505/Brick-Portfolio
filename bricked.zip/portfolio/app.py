import math
import re
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = "change-me-to-anything"   # needed for flash() messages

# ------------------------------------------------------------------
# EDIT YOUR PERSONAL INFO HERE (used by the Profile and Contact pages)
# ------------------------------------------------------------------
PROFILE = {
    "name": "Your Full Name",
    "nickname": "Builder",
    "year_course": "2nd Year - BS Computer Science",
    "section": "Section A",
    "subject": "Data Structures and Algorithms",
    "motto": "Everything is awesome when you build it brick by brick.",
    "about": "I love turning small pieces into big things, in code and in LEGO.",
    "hobbies": ["Coding", "Building LEGO", "Gaming"],
    "photo": "images/profile.jpg",          # put your photo in static/images/
    "email": "yourname@email.com",
    "phone": "+63 900 000 0000",
    "location": "Manila, Philippines",
    "github": "https://github.com/your-username",
    "facebook": "https://facebook.com/your-username",
}


# ------------------------------------------------------------------
# Pages
# ------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", p=PROFILE)


@app.route("/profile")
def profile():
    return render_template("profile.html", p=PROFILE)


@app.route("/contact")
def contact():
    return render_template("contact.html", p=PROFILE)


# ------------------------------------------------------------------
# Works
# ------------------------------------------------------------------
@app.route("/works")
def works():
    return render_template("works.html")


@app.route("/works/uppercase", methods=["GET", "POST"])
def uppercase():
    result = None
    if request.method == "POST":
        result = request.form.get("inputString", "").upper()
    return render_template("touppercase.html", result=result)


def to_number(text):
    """Return a positive float, or None if the input is invalid."""
    try:
        value = float(text)
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None


@app.route("/works/area/circle", methods=["GET", "POST"])
def acircle():
    result = radius = error = None
    if request.method == "POST":
        radius = to_number(request.form.get("radius"))
        if radius is None:
            error = "Please enter a number greater than 0."
        else:
            result = round(math.pi * radius ** 2, 2)
    return render_template("circle.html", result=result, radius=radius, error=error)


@app.route("/works/area/triangle", methods=["GET", "POST"])
def atriangle():
    result = base = height = error = None
    if request.method == "POST":
        base = to_number(request.form.get("base"))
        height = to_number(request.form.get("height"))
        if base is None or height is None:
            error = "Base and height must be numbers greater than 0."
        else:
            result = round(0.5 * base * height, 2)
    return render_template("triangle.html", result=result, base=base,
                           height=height, error=error)


# ------------------------------------------------------------------
# Infix to Postfix (Shunting-yard algorithm, uses a stack)
# ------------------------------------------------------------------
PRECEDENCE = {"+": 1, "-": 1, "*": 2, "/": 2, "^": 3}
RIGHT_ASSOC = {"^"}                      # 2^3^2 is read as 2^(3^2)
TOKEN_RE = re.compile(r"\s*(\d+\.?\d*|[A-Za-z_]\w*|[-+*/^()])")


def tokenize(expr):
    """Split '(A+B)*C' into ['(', 'A', '+', 'B', ')', '*', 'C']."""
    tokens, pos = [], 0
    while pos < len(expr):
        match = TOKEN_RE.match(expr, pos)
        if not match:
            bad = expr[pos:].lstrip()[0]
            raise ValueError(f"Unexpected character '{bad}'.")
        tokens.append(match.group(1))
        pos = match.end()
    if not tokens:
        raise ValueError("Type an expression first.")
    return tokens


def infix_to_postfix(tokens):
    """Return (postfix_tokens, steps). Each step records the stack and output."""
    stack, output, steps = [], [], []
    expect_operand = True                # True when an operand or '(' must come next

    def log(symbol, action):
        steps.append({"symbol": symbol, "action": action,
                      "stack": " ".join(stack), "output": " ".join(output)})

    for tok in tokens:
        if tok == "(":
            if not expect_operand:
                raise ValueError("Missing an operator before '('.")
            stack.append(tok)
            log(tok, "Push '(' onto the stack")

        elif tok == ")":
            if expect_operand:
                raise ValueError("Missing an operand before ')'.")
            while stack and stack[-1] != "(":
                output.append(stack.pop())
            if not stack:
                raise ValueError("There is a ')' without a matching '('.")
            stack.pop()                  # discard the '('
            log(tok, "Pop operators to the output until '(' is found")

        elif tok in PRECEDENCE:
            if expect_operand:
                raise ValueError(f"The operator '{tok}' needs an operand before it "
                                 "(negative numbers are not supported).")
            while (stack and stack[-1] != "("
                   and (PRECEDENCE[stack[-1]] > PRECEDENCE[tok]
                        or (PRECEDENCE[stack[-1]] == PRECEDENCE[tok]
                            and tok not in RIGHT_ASSOC))):
                output.append(stack.pop())
            stack.append(tok)
            log(tok, "Pop higher or equal operators, then push this operator")
            expect_operand = True

        else:                            # operand
            if not expect_operand:
                raise ValueError(f"Missing an operator before '{tok}'.")
            output.append(tok)
            log(tok, "Operand: send straight to the output")
            expect_operand = False

    if expect_operand:
        raise ValueError("The expression cannot end with an operator.")
    while stack:
        top = stack.pop()
        if top == "(":
            raise ValueError("There is a '(' without a matching ')'.")
        output.append(top)
    log("end", "Pop everything left on the stack to the output")
    return output, steps


def is_number(text):
    try:
        float(text)
        return True
    except ValueError:
        return False


def evaluate_postfix(postfix):
    """Evaluate a postfix list made only of numbers and operators."""
    stack = []
    for tok in postfix:
        if tok in PRECEDENCE:
            b, a = stack.pop(), stack.pop()
            if tok == "+": stack.append(a + b)
            elif tok == "-": stack.append(a - b)
            elif tok == "*": stack.append(a * b)
            elif tok == "/": stack.append(a / b)
            else: stack.append(a ** b)
        else:
            stack.append(float(tok))
    value = stack[0]
    if isinstance(value, complex):
        raise ValueError("The result is not a real number.")
    return int(value) if float(value).is_integer() else round(value, 4)


@app.route("/works/infix", methods=["GET", "POST"])
def infix():
    expression = request.form.get("expression", "").strip()
    postfix = steps = value = error = None
    if request.method == "POST":
        try:
            postfix, steps = infix_to_postfix(tokenize(expression))
            if all(is_number(t) or t in PRECEDENCE for t in postfix):
                try:
                    value = evaluate_postfix(postfix)
                except ZeroDivisionError:
                    value = "Cannot divide by zero"
                except (OverflowError, ValueError):
                    value = "Result is too large or not a real number"
        except ValueError as e:
            error = str(e)
    return render_template("infix.html", expression=expression, postfix=postfix,
                           steps=steps, value=value, error=error)


# ------------------------------------------------------------------
# Linked list (Lab item 5)
# ------------------------------------------------------------------
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def insert_head(self, data):
        node = Node(data)
        node.next = self.head
        self.head = node

    def insert_tail(self, data):
        node = Node(data)
        if not self.head:
            self.head = node
            return
        cur = self.head
        while cur.next:
            cur = cur.next
        cur.next = node

    def delete(self, data):
        """Delete the first node holding `data`. Returns True if found."""
        cur, prev = self.head, None
        while cur:
            if cur.data == data:
                if prev:
                    prev.next = cur.next
                else:
                    self.head = cur.next
                return True
            prev, cur = cur, cur.next
        return False

    def search(self, data):
        """Return the position (0-based) of `data`, or -1."""
        cur, i = self.head, 0
        while cur:
            if cur.data == data:
                return i
            cur, i = cur.next, i + 1
        return -1

    def reverse(self):
        prev, cur = None, self.head
        while cur:
            cur.next, prev, cur = prev, cur, cur.next
        self.head = prev

    def clear(self):
        self.head = None

    def to_list(self):
        items, cur = [], self.head
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items


my_list = LinkedList()
for starter in ("LEGO", "Flask", "Python"):
    my_list.insert_tail(starter)


@app.route("/works/linkedlist", methods=["GET", "POST"])
def linkedlist():
    found = request.args.get("found", type=int)
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        needs_value = action in ("head", "tail", "delete", "search")

        if needs_value and not value:
            flash("Type a value first.", "error")
        elif action == "head":
            my_list.insert_head(value)
            flash(f"Added '{value}' to the front.", "ok")
        elif action == "tail":
            my_list.insert_tail(value)
            flash(f"Added '{value}' to the end.", "ok")
        elif action == "delete":
            if my_list.delete(value):
                flash(f"Removed '{value}'.", "ok")
            else:
                flash(f"'{value}' is not in the list.", "error")
        elif action == "search":
            pos = my_list.search(value)
            if pos == -1:
                flash(f"'{value}' is not in the list.", "error")
            else:
                flash(f"Found '{value}' at position {pos}.", "ok")
                return redirect(url_for("linkedlist", found=pos))
        elif action == "reverse":
            my_list.reverse()
            flash("List reversed.", "ok")
        elif action == "clear":
            my_list.clear()
            flash("List cleared.", "ok")
        return redirect(url_for("linkedlist"))

    return render_template("linkedlist.html", items=my_list.to_list(), found=found)


if __name__ == "__main__":
    app.run(debug=True)
