# LEGO Brick Portfolio (Flask)

## Run it
    pip install flask
    python app.py
Open http://127.0.0.1:5000

## Where to put things
- Your info (name, course, motto, email...): the PROFILE dictionary at the top of app.py
- Your photo: static/images/profile.jpg  (or change "photo" in PROFILE)
- Colors: the :root block at the top of static/css/style.css
- 3D shapes: static/js/shapes.js
- Offline 3D: download three.min.js (r128) into static/js/ and change the <script src> in circle.html and triangle.html to {{ url_for('static', filename='js/three.min.js') }}

## Folder layout
    app.py
    static/css/style.css
    static/js/shapes.js
    static/images/profile.jpg   <- your photo
    templates/  base, index, profile, contact, works,
                touppercase, circle, triangle, linkedlist
